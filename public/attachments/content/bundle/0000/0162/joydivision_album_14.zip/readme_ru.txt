If you got this album for free, please contribute to the artist as much as you want here:
http://joydivision.kroogi.test:3000/ru/download/14-Joy-Division-Closer-2011.html

Album title: Closer


Tracklist: 
01. Isolation
02. Decades

Tracks lyrics/descriptions:

